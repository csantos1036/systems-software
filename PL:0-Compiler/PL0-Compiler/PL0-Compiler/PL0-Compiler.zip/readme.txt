Author Names: Jacob Campbell and Carolina Santos

To compile and run the code, the input file name will be read as a command line argument at runtime, such as $ ./a.out test1.txt -l -a -v. According to the directives, the program will print the corresponding output. -l will print the lexeme table, tokens, and token list. -a will print the generated assembly. -v will print out the stack trace. Any errors the program encounters will be printed. 

STEPS: 
1) $ make
2) $ bash tester.sh 
or 
1) $ make
2) $ ./a.out test1.txt -l -a -v